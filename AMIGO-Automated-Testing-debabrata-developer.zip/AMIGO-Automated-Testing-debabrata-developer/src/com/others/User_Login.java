package com.others;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class User_Login extends LoginToSalesforce {
    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    public User_Login() throws IOException {
    }

    //@Test(priority = 1)
    public WebDriver LoginAnyUser(WebDriver driver, String UserName) throws InterruptedException {

        if(UserName == "login"){
            //Initiate Wait
            WebDriverWait wait = new WebDriverWait(driver, 50);

            //get UserName & Password
            String username = sheet.getRow(1).getCell(2).getStringCellValue();
            System.out.println(username);
            String password = sheet.getRow(2).getCell(2).getStringCellValue();
            System.out.println(password);

            //click logout
            WebElement myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'Log out as')]")));
            myDynamicElement.click();
            Thread.sleep(5000);

            //give UserName & Password & Click to Login
            myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='username']")));
            myDynamicElement.sendKeys(username);
            Thread.sleep(1000);
            myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='password']")));
            myDynamicElement.sendKeys(password);
            Thread.sleep(1000);
            myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("Login")));
            myDynamicElement.click();
            Thread.sleep(5000);
            driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        }
        else{
            //get sObject URL
            String sObject = sheet.getRow(58).getCell(2).getStringCellValue();

            //redirect to manage user page
            driver.get(sObject);
            Thread.sleep(5000);

            //Initiate Wait
            WebDriverWait wait = new WebDriverWait(driver, 50);

            //click user
            WebElement myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[text()='"+UserName+"']")));
            myDynamicElement.click();
            Thread.sleep(5000);

            //click login
            myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name=\"login\"]")));
            myDynamicElement.click();
            Thread.sleep(5000);
            driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        }

        return driver;
    }
}

        /*User_Login helper = null;
        try {
            helper = new User_Login();
        } catch (IOException e) {
            e.printStackTrace();
        }
        driver = helper.LoginAnyUser(driver, UserAliasName);
        driver = helper.LoginAnyUser(driver, "login");*/
