package com.testCase;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Action_Item extends LOGIN_CLASS{
    String RecURL;
    // Read Excel File
    File src=new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input=new FileInputStream(src);
    XSSFWorkbook workbook=new XSSFWorkbook(input);
    XSSFSheet sheet=workbook.getSheetAt(0);

    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();

    public Action_Item()throws IOException,IOException{
    }

    @Test(priority=0)
    public void CreateActionItem()throws InterruptedException{
        String sObject = "";
        String OrgName = "";
        String PortName = "";
        String ProgramName = "";
        String ProjectName = "";
        String UserName = "";
        String DeliverableName = "";
        String UserName1 = "";
        String UserName2 = "";

        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();
            if(check.equals("PlatinumPMO__Action_Items__c")){
                sObject = row.getCell(2).getStringCellValue();
                //System.out.println("the if value--->"+row.getCell(2).getStringCellValue());
            }
            if(check.equals("PlatinumPMO__Organization__c")){
                OrgName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Portfolio__c")){
                PortName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("User")){
                UserName = row.getCell(4).getStringCellValue();
                UserName1 = row.getCell(3).getStringCellValue();
                UserName2 = row.getCell(6).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Program__c")){
                ProgramName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Project__c")){
                ProjectName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Deliverable__c")){
                DeliverableName = row.getCell(3).getStringCellValue();
            }
        }
        //-------------END-------------------------------

        //get sObject URL
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);

        WebDriverWait wait=new WebDriverWait(driver,50);

        //click New Button
        WebElement myDynamicElement=(new WebDriverWait(driver,30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Clicking on Associated Organization
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder=\"Search Organization...\"]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on Associated Portfolio
        driver.findElement(By.xpath("//input[@placeholder=\"Search Portfolios...\"]")).sendKeys(PortName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+PortName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on Associated program
        driver.findElement(By.xpath("//input[@placeholder=\"Search Programs...\"]")).sendKeys(ProgramName);
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+ProgramName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //clicking on Associated project
        driver.findElement(By.xpath("//input[@placeholder=\"Search Projects...\"]")).sendKeys(ProjectName);
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+ProjectName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //ActionItem Name
        driver.findElement(By.xpath("//input[@class=\" input\" and @maxlength=\"80\"]")).sendKeys("Test Selenium ActionItem ");
        Thread.sleep(1000);

        //ActionItem Type
        driver.findElement(By.xpath("(//a[@class=\"select\" and @role=\"button\"])[1]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"Action Item\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //ActionItem Coordinate
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@class=\" default input uiInput uiInputTextForAutocomplete uiInput--default uiInput--input uiInput uiAutocomplete uiInput--default uiInput--lookup\" and @title=\"Search People\"])[1]")));
        myDynamicElement.sendKeys(UserName);
        Thread.sleep(5000);
        myDynamicElement.sendKeys(Keys.ARROW_DOWN);
        Thread.sleep(1000);
        myDynamicElement.sendKeys(Keys.ENTER);
        Thread.sleep(1000);


        //clicking on associated DeliverableName
        driver.findElement(By.xpath("//input[@title=\"Search Deliverables\"]")).sendKeys(DeliverableName);
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+DeliverableName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //ActionItem Owner
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@title=\"Search People\"])[2]")));
        myDynamicElement.sendKeys(UserName1);
        Thread.sleep(5000);
        myDynamicElement.sendKeys(Keys.ARROW_DOWN);
        Thread.sleep(1000);
        myDynamicElement.sendKeys(Keys.ENTER);
        Thread.sleep(1000);


        //ActionItem Signoff Owner
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@title=\"Search People\"])[3]")));
        myDynamicElement.sendKeys(UserName2);
        Thread.sleep(5000);
        myDynamicElement.sendKeys(Keys.ARROW_DOWN);
        Thread.sleep(1000);
        myDynamicElement.sendKeys(Keys.ENTER);
        Thread.sleep(1000);


        //Due Date
        driver.findElement(By.xpath("//a[@class=\"datePicker-openIcon display\"]")).click();
        Thread.sleep(1000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='17']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Priority
        driver.findElement(By.xpath("(//a[@class=\"select\"])[2]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"Medium\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Description
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("ok");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Save ActionItem
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage=myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue="Action Items \"Test Selenium ActionItem \" was created.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

        //assign url to RecURL variable
        RecURL = driver.getCurrentUrl();
    }

    @Test(priority=2)
    public void EditActionItem()throws InterruptedException{
        WebDriverWait wait=new WebDriverWait(driver,30);

        //Click Edit Button
        WebElement myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Action_Items__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='Edit'])[1]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //ActionItem Name Change
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\" input\" and @maxlength=\"80\"]")));
        myDynamicElement.clear();
        Thread.sleep(5000);
        myDynamicElement.sendKeys("TEST Selenium ActionItem Edit");
        Thread.sleep(1000);


        //ActionItem Type
        driver.findElement(By.xpath("(//a[@class=\"select\" and @role=\"button\"])[1]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"Watch List Item\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comments
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys(" Test AI");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage=myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue="Action Items \"TEST Selenium ActionItem Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

    }

    @Test(priority = 3)
    public void SendtoCoordination() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Action_Items__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test STC");
        Thread.sleep(1000);

        //STC Click
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button--neutral slds-button slds-button_brand uiButton\"])[1]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send to Coordination";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='In Coordination']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }


    @Test(priority = 4)
    public void InResolution() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserAliasName="";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("User_Management")){
                UserAliasName = row.getCell(4).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Action_Items__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test In Resolution");
        Thread.sleep(1000);

        //Click Resolution
        driver.findElement(By.xpath("//span[text()='Send To Resolution']")).click();
        Thread.sleep(2000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send to Resolution";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='In Resolution']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }

    @Test(priority = 5)
    public void ReadyToTest() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Action_Items__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test RTT");
        Thread.sleep(1000);

        //RTT Click
        driver.findElement(By.xpath("//span[text()='Ready To Test']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully send for Resolved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Resolved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }

    @Test(priority = 6)
    public void MinorChange() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click Edit Button
        WebElement myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Action_Items__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //minor change click
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a minor change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Description
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"ql-editor slds-rich-text-area__content slds-text-color_weak slds-grow\"]")));
        myDynamicElement.clear();
        Thread.sleep(5000);
        myDynamicElement.sendKeys("minor Change");
        Thread.sleep(1000);


        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test minor");
        Thread.sleep(2000);

        //Click Save Button
        driver.findElement(By.xpath("(//span[text()='Save'])")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage=myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue="Action Items \"TEST Selenium ActionItem Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

    }

    @Test(priority = 7)
    public void SignificantChange() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click Edit Button
        WebElement myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Action_Items__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Significant change click
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a significant change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Description
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")));
        myDynamicElement.clear();
        Thread.sleep(5000);
        myDynamicElement.sendKeys("significant Change");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test significant");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("(//span[text()='Save'])")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Action Items \"TEST Selenium ActionItem Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);
    }
    @Test(priority = 8)
    public void ReadyToTest1() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Action_Items__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test RTT");
        Thread.sleep(1000);

        //RTT Click
        driver.findElement(By.xpath("//span[text()='Ready To Test']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully send for Resolved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Resolved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }




        @Test(priority = 9)
    public void Approval() throws InterruptedException {

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 30);

            String UserAliasName="";


            //-----dynamically fetch value from excel------
            for(int i=0; i<rowCount+1; i++){
                Row row = sheet.getRow(i);
                String check = row.getCell(1).getStringCellValue();


                if(check.equals("User_Management")){
                    UserAliasName = row.getCell(6).getStringCellValue();

                }

            }
            //-------------END-------------------------------

        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Action_Items__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Approved");
        Thread.sleep(1000);

        //Approve Click
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button--neutral slds-button slds-button_brand uiButton\"])[1]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Approved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        Thread.sleep(5000);
    }

}
