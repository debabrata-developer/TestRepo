package com.testCase;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Benefit extends LOGIN_CLASS {

    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    public Benefit() throws IOException, IOException {
    }

    @Test(priority = 0)
    public void CreateBenefit() throws InterruptedException {
        //get sObject URL
        String sObject = sheet.getRow(52).getCell(2).getStringCellValue();
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 50);

        //Click New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Associated Organization
        String OrgName = sheet.getRow(11).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"search..\"])[1]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //Associated Portfolio
        //clicking on Associated Portfolio
        String PortName = sheet.getRow(12).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[2]")).sendKeys(PortName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+PortName+"\"]")).click();
        Thread.sleep(1000);

        //Associated Program Financial
        String PorgFinanName = sheet.getRow(53).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[3]")).sendKeys(PorgFinanName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+PorgFinanName+"\"]")).click();
        Thread.sleep(1000);

        //Benefit Name
        driver.findElement(By.xpath("//input[@name=\"BenefitName\"]")).sendKeys("Test Selenium Benefit");
        Thread.sleep(1000);

        //Benefit Type
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//select[@class=\"slds-select\"])[1]")));
        myDynamicElement.sendKeys("Financial Benefit (Hard)");
        Thread.sleep(1000);

        //Expected Benefit
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Business Process
        String BPName = sheet.getRow(19).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[4]")).sendKeys(BPName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+BPName+"\"]")).click();
        Thread.sleep(1000);

        //Deleverable
        String DelivName = sheet.getRow(15).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[5]")).sendKeys(DelivName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+DelivName+"\"]")).click();
        Thread.sleep(1000);

        //Current State Baseline
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        /*//Measurement
        String MeasureName = sheet.getRow(43).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[6]")).sendKeys(MeasureName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+MeasureName+"\"]")).click();
        Thread.sleep(1000);*/

        //Other Measurement
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Measurement Responsibility
        String MRName = sheet.getRow(51).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[7]")).sendKeys(MRName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+MRName+"\"]")).click();
        Thread.sleep(1000);

        //Anticipated Measurement Start
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name=\"AnticipatedMeasurementStart\"]")));
        myDynamicElement.sendKeys("Jun 17, 2020");
        Thread.sleep(1000);

        //Measurement Frequesncy
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[2]")).sendKeys("Hourly");
        Thread.sleep(1000);

        //Starting Quarter
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[3]")).sendKeys("Q1");
        Thread.sleep(1000);

        //Starting Year
        driver.findElement(By.xpath("//input[@name=\"number\"]")).sendKeys("2020");
        Thread.sleep(1000);

        //Financial Type
        driver.findElement(By.xpath("//select[@name=\"FinancialBenefitType\"]")).sendKeys("Revenue");
        Thread.sleep(1000);

        //Financial Category
        driver.findElement(By.xpath("//select[@name=\"FinancialCategory\"]")).sendKeys("Increase Product Sales");
        Thread.sleep(1000);

        //Account
       //driver.findElement(By.xpath("//select[@name=\"Account\"]")).sendKeys("");

        //Starting Quarter
        driver.findElement(By.xpath("//input[@name=\"StartingQuarterC\"]")).sendKeys("1");
        Thread.sleep(1000);

        //Starting Quarter+1
        driver.findElement(By.xpath("(//input[@name=\"StartingQuarter\"])[1]")).sendKeys("2");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "The record was Updated.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

    }
    @Test(priority = 1)
    public void EditBenefit() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 50);

        //Click Edit Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Name
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name=\"BenefitName\"])[2]")));
        myDynamicElement.clear();
        Thread.sleep(1000);
        myDynamicElement.sendKeys("Test Selenium Benefit-Edit");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("(//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"])[5]")).sendKeys("Test Historical Comment-Edit");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "The record was Updated.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

    }
    @Test(priority = 2)
    public void CreateBenefit1() throws InterruptedException {
        //get sObject URL
        String sObject = sheet.getRow(52).getCell(2).getStringCellValue();
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 50);

        //Click New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Associated Organization
        String OrgName = sheet.getRow(11).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"search..\"])[1]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //Associated Portfolio
        //clicking on Associated Portfolio
        String PortName = sheet.getRow(12).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[2]")).sendKeys(PortName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+PortName+"\"]")).click();
        Thread.sleep(1000);

        //Associated Program Financial
        String PorgFinanName = sheet.getRow(53).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[3]")).sendKeys(PorgFinanName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+PorgFinanName+"\"]")).click();
        Thread.sleep(1000);

        //Benefit Name
        driver.findElement(By.xpath("//input[@name=\"BenefitName\"]")).sendKeys("Test Selenium Benefit");
        Thread.sleep(1000);

        //Benefit Type
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//select[@class=\"slds-select\"])[1]")));
        myDynamicElement.sendKeys("Non-Financial Benefit (Soft)");
        Thread.sleep(1000);

        //Expected Benefit
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Business Process
        String BPName = sheet.getRow(19).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[4]")).sendKeys(BPName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+BPName+"\"]")).click();
        Thread.sleep(1000);

        //Deleverable
        String DelivName = sheet.getRow(15).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[5]")).sendKeys(DelivName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+DelivName+"\"]")).click();
        Thread.sleep(1000);

        //Current State Baseline
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

         /*//Measurement
        String MeasureName = sheet.getRow(43).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[6]")).sendKeys(MeasureName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+MeasureName+"\"]")).click();
        Thread.sleep(1000);*/

        //Other Measurement
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Measurement Responsibility
        String MRName = sheet.getRow(51).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[7]")).sendKeys(MRName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+MRName+"\"]")).click();
        Thread.sleep(1000);

        //Anticipated Measurement Start
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name=\"AnticipatedMeasurementStart\"]")));
        myDynamicElement.sendKeys("Jun 17, 2020");
        Thread.sleep(1000);

        //Measurement Frequesncy
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[2]")).sendKeys("Hourly");
        Thread.sleep(1000);

        //Non Financial Category
        driver.findElement(By.xpath("//select[@name=\"NonFinancialCategory\"]")).sendKeys("Improved Capabilities");
        Thread.sleep(1000);

        //Unit Of Measure
        driver.findElement(By.xpath("//select[@name=\"UnitOfMeasure\"]")).sendKeys("Years");
        Thread.sleep(1000);

        //Baseline Value
        driver.findElement(By.xpath("//input[@name=\"BaselineValue\"]")).sendKeys("50");
        Thread.sleep(1000);

        //Baseline Date
        driver.findElement(By.xpath("//input[@name=\"BaselineDate\"]")).sendKeys("Jun 25, 2020");
        Thread.sleep(1000);

        //Target Value
        driver.findElement(By.xpath("//input[@name=\"TargetValue\"]")).sendKeys("20");
        Thread.sleep(1000);

        //Target Date
        driver.findElement(By.xpath("//input[@name=\"TargetDate\"]")).sendKeys("Jun 27, 2020");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "The record was Updated.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

    }

    @Test(priority = 3)
    public void EditBenefit1() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 50);

        //Click Edit Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Name
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name=\"BenefitName\"])[2]")));
        myDynamicElement.clear();
        Thread.sleep(1000);
        myDynamicElement.sendKeys("Test Selenium Benefit-Edit");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("(//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"])[5]")).sendKeys("Test Historical Comment-Edit");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "The record was Updated.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

    }
}
