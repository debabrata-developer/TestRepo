package com.testCase;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Change_Request_Log extends LOGIN_CLASS {
    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();


    public Change_Request_Log() throws IOException, IOException {
    }
    @Test(priority = 0)
    public void CreateCRL() throws InterruptedException {

        String sObject = "";
        String OrgName = "";
        String PortName = "";
        String ProgramName = "";
        String ProjectName ="";
        String userName = "";
        String SystemName ="";
       String DeliverableName ="";
        String DefectLogName ="";
        String StakeholderGroupsName ="";
        String UserName ="";
        String UserName1 ="";
        String UserName2 ="";

        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();
            if(check.equals("PlatinumPMO__Change_Request_Log__c")){
                sObject = row.getCell(2).getStringCellValue();
                //System.out.println("the if value--->"+row.getCell(2).getStringCellValue());
            }
            if(check.equals("PlatinumPMO__Organization__c")){
                OrgName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Portfolio__c")){
                PortName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("User")){
                userName = row.getCell(4).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Program__c")){
                ProgramName = row.getCell(3).getStringCellValue();

            }
            if(check.equals("PlatinumPMO__Project__c")){
                ProjectName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__System__c")){
                SystemName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Deliverable__c")){
                DeliverableName = row.getCell(3).getStringCellValue();

            }
            if(check.equals("PlatinumPMO__Defect_Log__c")){
                DefectLogName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Stakeholder_Groups__c")){
                StakeholderGroupsName = row.getCell(3).getStringCellValue();
            }

            if(check.equals("User")){
                UserName = row.getCell(4).getStringCellValue();
                UserName1 = row.getCell(4).getStringCellValue();
                UserName2 = row.getCell(4).getStringCellValue();
            }
        }
        //-------------END-------------------------------



        //get sObject URL
        //String sObject = sheet.getRow(21).getCell(2).getStringCellValue();
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 50);

        //click New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\" or @data-aura-rendered-by=\"659:0\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Clicking on Associated Organization
        //String OrgName = sheet.getRow(11).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder=\"Search Organization...\"]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on Associated Portfolio
        //String PortName = sheet.getRow(12).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Portfolios...\"]")).sendKeys(PortName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+PortName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on associated program
       // String ProgramName = sheet.getRow(13).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Programs...\"]")).sendKeys(ProgramName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+ProgramName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //clicking on associated project
        //String ProjectName = sheet.getRow(14).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Projects...\"]")).sendKeys(ProjectName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+ProjectName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //CRL Name
        driver.findElement(By.xpath("//div/input[@type=\"text\" and @maxlength=\"80\"]")).sendKeys("Test Selenium Change Request Log");
        Thread.sleep(1000);

        //Program Phase
        driver.findElement(By.xpath("(//a[@class=\"select\"])[1]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"ASAP: 0- Initiation\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Change Request Description
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Business Junction
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Change Request Type
        driver.findElement(By.xpath("(//a[@class=\"select\"])[2]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"Business Process\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //clicking on associated DeliverableName
       // String DeliverableName = sheet.getRow(15).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@title=\"Search Deliverables\"]")).sendKeys(DeliverableName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+DeliverableName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //clicking on associated SystemName
        //String SystemName = sheet.getRow(33).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@title=\"Search Systems\"]")).sendKeys(SystemName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+SystemName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //clicking on associated DefectLogName
        //String DefectLogName = sheet.getRow(25).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@title=\"Search Defect Log\"]")).sendKeys(DefectLogName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+DefectLogName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Change Request Sponsor
       // String UserName = sheet.getRow(37).getCell(4).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@title=\"Search People\"])[1]")));
        myDynamicElement.sendKeys(UserName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+UserName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Change Review Board
        //String StakeholderGroupsName = sheet.getRow(42).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//div/input[@title=\"Search Stakeholder Groups\"]")).sendKeys(StakeholderGroupsName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+StakeholderGroupsName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Impact Assessment Owner
        //String UserName1 = sheet.getRow(37).getCell(4).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@title=\"Search People\"])[2]")));
        myDynamicElement.sendKeys(UserName1);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\""+UserName1+"\"])[2]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Impact Assessment Due Date
        driver.findElement(By.xpath("//a[@class=\"datePicker-openIcon display\"]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='15']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Impact Assessment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("testing");
        Thread.sleep(1000);

        //Estimated Project Hours- Breakdown
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("testing");
        Thread.sleep(1000);

        //Overall Project Impact
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("testing");
        Thread.sleep(1000);

        //Potential Workaround
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("testing");
        Thread.sleep(1000);

        //Estimated Hours to Complete Change
        driver.findElement(By.xpath("(//input[@class=\"input uiInputSmartNumber\"])[1]")).sendKeys("3");
        Thread.sleep(1000);

        //Estimated Cost for Change
        driver.findElement(By.xpath("//input[@class=\"input uiInputSmartNumber\" and @max=\"99999999999999\"]")).sendKeys("$50");
        Thread.sleep(1000);

        //Change Request Delivery Manager
        //String UserName2 = sheet.getRow(37).getCell(4).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"Search People...\"])[3]")));
        myDynamicElement.sendKeys(UserName2);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\""+UserName2+"\"])[3]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Development Details
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Transport Number
        driver.findElement(By.xpath("//textarea[@role=\"textbox\"]")).sendKeys("323123");
        Thread.sleep(1000);

        //Implementation Notes
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("implemented");
        Thread.sleep(1000);

        //Implementation Environment
        driver.findElement(By.xpath("//input[@maxlength=\"50\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Save CRL
        driver.findElement(By.xpath("//div//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Change Request Log \"Test Selenium Change Request Log\" was created.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);
    }

    @Test(priority = 1)
    public void EditCRL() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click Edit Button
        WebElement myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//button[@class=\"slds-button slds-button_icon-border-filled\"])")));
        myDynamicElement.click();
        Thread.sleep(1000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //CRL Name Change
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\" input\" and @maxlength=\"80\"]")));
        myDynamicElement.clear();
        myDynamicElement.sendKeys("Test Selenium Change Request Log-Edit");
        Thread.sleep(1000);

        //Transport Number
        driver.findElement(By.xpath("//textarea[@role=\"textbox\"]")).sendKeys("3231234354");
        Thread.sleep(1000);

        //Historical Comments
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys(" Test Historical Comment");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Change Request Log \"Test Selenium Change Request Log-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);
    }
    @Test(priority = 2)
    public void AddIssueLog() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String IssueLogName= "";



        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("PlatinumPMO__Issue_Log__c")){
                IssueLogName = row.getCell(3).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        //Click Add Issue
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Change_Request_Log__c.PlatinumPMO__Add_Issue\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //clicking on associated IssueLogName
        //String IssueLogName = sheet.getRow(18).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"search..\"]")).sendKeys(IssueLogName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+IssueLogName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comments
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys(" Test Historical issue");
        Thread.sleep(1000);

        //Click Add Button
        driver.findElement(By.xpath("//span[text()='Add Issue Log']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);
    }

    @Test(priority = 3)
    public void AddImpactedBusinessTransaction() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String BusinessTransaction= "";



        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("PlatinumPMO__Business_Transaction_Ownership_Library__c")){
                BusinessTransaction = row.getCell(3).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Change_Request_Log__c.PlatinumPMO__Add_Impacted_Business_Transaction\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //clicking on Associated Impacted Business Transaction
        //String BusinessTransaction= sheet.getRow(50).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"search..\"]")).sendKeys(BusinessTransaction);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+BusinessTransaction+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Save Add Impacted Business Transaction
        driver.findElement(By.xpath("//span[text()='Add Business Transaction']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

    }

}
