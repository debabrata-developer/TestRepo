package com.testCase;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Cost extends LOGIN_CLASS {
    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    public Cost() throws IOException, IOException {
    }

    @Test(priority = 0)
    public void CreateCost() throws InterruptedException {
        //get sObject URL
        String sObject = sheet.getRow(55).getCell(2).getStringCellValue();
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 50);

        //Click New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Associated Organization
        String OrgName = sheet.getRow(11).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"search..\"])[1]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //Associated Portfolio
        //clicking on Associated Portfolio
        String PortName = sheet.getRow(12).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[2]")).sendKeys(PortName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+PortName+"\"]")).click();
        Thread.sleep(1000);

        //Associated Program Financial
        String PorgFinanName = sheet.getRow(53).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[3]")).sendKeys(PorgFinanName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+PorgFinanName+"\"]")).click();
        Thread.sleep(1000);

        //cost Name
        driver.findElement(By.xpath("//input[@name=\"CostName\"]")).sendKeys("Test Selenium Cost");
        Thread.sleep(1000);

        //Description
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Cost Type
        driver.findElement(By.xpath("//select[@name=\"controllerFld\"]")).sendKeys("Labor Cost");
        Thread.sleep(1000);

        //Cost Category
        driver.findElement(By.xpath("//select[@name=\"dependentFld\"]")).sendKeys("Business Analyst");
        Thread.sleep(1000);

        //Expense Type
        driver.findElement(By.xpath("//select[@name=\"ExpenseType\"]")).sendKeys("Capital");
        Thread.sleep(1000);

        //Account
        //driver.findElement(By.xpath("//select[@name=\"Account\"]")).sendKeys("");

        //Starting Quarter
        driver.findElement(By.xpath("//select[@name=\"sQuerter\"]")).sendKeys("Q1");
        Thread.sleep(1000);

        //Starting Quarter
        driver.findElement(By.xpath("(//input[@class=\"slds-input\"])[3]")).sendKeys("1");
        Thread.sleep(1000);

        //Starting Quarter
        driver.findElement(By.xpath("(//input[@class=\"slds-input\"])[4]")).sendKeys("2");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "The record was Updated.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);
    }

    @Test(priority = 1)
    public void EditCost() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 50);

        //Click Edit Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Name
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name=\"CostName\"])[2]")));
        myDynamicElement.clear();
        Thread.sleep(1000);
        myDynamicElement.sendKeys("Test Selenium Cost-Edit");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("(//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"])[2]")).sendKeys("Test Historical Comment-Edit");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "The record was Updated.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);
    }
}
