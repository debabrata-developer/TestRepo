package com.testCase;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Cutover_Event_Journal extends LOGIN_CLASS {
    String RecURL;

    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();

    public Cutover_Event_Journal() throws IOException {
    }

    @Test(priority = 1)
    public void CreateCEJ() throws InterruptedException {

        String sObject = "";
        String OrgName = "";
        String PortName = "";
        String ProgName = "";
        String userName = "";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();
            if(check.equals("PlatinumPMO__Cutover_Event_Journal__c")){
                sObject = row.getCell(2).getStringCellValue();
                //System.out.println("the if value--->"+row.getCell(2).getStringCellValue());
            }
            if(check.equals("PlatinumPMO__Organization__c")){
                OrgName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Portfolio__c")){
                PortName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("User")){
                userName = row.getCell(4).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Program__c")){
                ProgName = row.getCell(3).getStringCellValue();
            }
        }
        //-------------END-------------------------------



        //get sObject URL
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click On New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Click On Associated Organization
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@title=\"Search Organization\"]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //Click On Associated Portfolio
        driver.findElement(By.xpath("//input[@title=\"Search Portfolios\"]")).sendKeys(PortName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+PortName+"\"]")).click();
        Thread.sleep(1000);

        //Click On Associated Program
        driver.findElement(By.xpath("//input[@title=\"Search Programs\"]")).sendKeys(ProgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+ProgName+"\"]")).click();
        Thread.sleep(1000);

        //Cutover Event Journal Name
        driver.findElement(By.xpath("//input[@class=\" input\"]")).sendKeys("Test Selenium CEJ");
        Thread.sleep(1000);

        //Priority
        driver.findElement(By.xpath("//a[@class=\"select\"]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[@title=\"Normal\"]")).click();
        Thread.sleep(1000);

        //Event Description
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing Event");
        Thread.sleep(1000);

        //Cutover Event Coordinator
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[1]")).sendKeys(userName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("(//div[@title=\""+userName+"\"])[1]")).click();
        Thread.sleep(1000);

        //Cutover Event Owner
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[2]")).sendKeys(userName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("(//div[@title=\""+userName+"\"])[2]")).click();
        Thread.sleep(1000);

        //Cutover Event Resolution Signoff
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[3]")).sendKeys(userName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("(//div[@title=\""+userName+"\"])[3]")).click();
        Thread.sleep(1000);

        //Cutover Resolution
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing Cutover Resolution");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save CEJ
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Cutover Event Journal \"Test Selenium CEJ\" was created.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

        //assign url to RecURL variable
        RecURL = driver.getCurrentUrl();
    }

    @Test(priority = 2)
    public void EditCEJ() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Edit Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Cutover_Event_Journal__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Edit popup
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Edit']")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //CEJ Name
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\" input\"]")));
        myDynamicElement.clear();
        myDynamicElement.sendKeys("Test Selenium CEJ-Edit");
        Thread.sleep(1000);

        //Prority
        driver.findElement(By.xpath("//a[@class=\"select\"]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[@title=\"Low\"]")).click();
        Thread.sleep(1000);

        //Historical comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment-Edit");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Cutover Event Journal \"Test Selenium CEJ-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);
    }

    @Test(priority = 3)
    public void SendtoCoordination() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Cutover_Event_Journal__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test STC");
        Thread.sleep(1000);

        //STC Click
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button--neutral slds-button slds-button_brand uiButton\"])[1]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send to Coordination";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);


        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='In Coordination']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }


    @Test(priority = 4)
    public void InResolution() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserAliasName="";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("User_Management")){
                UserAliasName = row.getCell(4).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Cutover_Event_Journal__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test In Resolution");
        Thread.sleep(1000);

        //Click Resolution
        driver.findElement(By.xpath("//span[text()='Send For Resolution']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send to Resolution";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='In Resolution']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }

    @Test(priority = 5)
    public void ReadyToTest() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Cutover_Event_Journal__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test RTT");
        Thread.sleep(1000);

        //RTT Click
        driver.findElement(By.xpath("//span[text()='Ready To Test']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully send for Resolved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Resolved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }


    @Test(priority = 6)
    public void MinorChange() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click Edit Button
        WebElement myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Cutover_Event_Journal__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //minor change click
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a minor change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Description
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"ql-editor slds-rich-text-area__content slds-text-color_weak slds-grow\"]")));
        myDynamicElement.clear();
        Thread.sleep(5000);
        myDynamicElement.sendKeys("minor Change");
        Thread.sleep(1000);


        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test minor");
        Thread.sleep(2000);

        //Click Save Button
        driver.findElement(By.xpath("(//span[text()='Save'])")).click();
        Thread.sleep(2000);

        //get Toast Message
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage=myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue="Cutover Event Journal \"Test Selenium CEJ-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

    }

    @Test(priority = 7)
    public void SignificantChange() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click Edit Button
        WebElement myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Cutover_Event_Journal__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Significant change click
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a significant change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Description
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")));
        myDynamicElement.clear();
        Thread.sleep(5000);
        myDynamicElement.sendKeys("significant Change");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test significant");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Cutover Event Journal \"Test Selenium CEJ-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);
    }

    @Test(priority = 8)
    public void Approval() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Cutover_Event_Journal__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Approved");
        Thread.sleep(1000);

        //Approve Click
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button--neutral slds-button slds-button_brand uiButton\"])[1]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);


        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Approved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        Thread.sleep(5000);
    }
}
