package com.testCase;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Issue_Log extends LOGIN_CLASS {
    String RecURL;

    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();


    public Issue_Log() throws IOException, IOException {
    }

    @Test(priority = 0)
    public void CreateIssueLog() throws InterruptedException {

        String sObject = "";
        String OrgName = "";
        String PortName = "";
        String ProgramName = "";
        String RiskRegister ="";
        String ChangeRequestLogName ="";

        String UserName = "";
        String UserName1 ="";
        String UserName2 ="";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();
            if(check.equals("PlatinumPMO__Issue_Log__c")){
                sObject = row.getCell(2).getStringCellValue();
                //System.out.println("the if value--->"+row.getCell(2).getStringCellValue());
            }
            if(check.equals("PlatinumPMO__Organization__c")){
                OrgName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Portfolio__c")){
                PortName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("User")){
                UserName = row.getCell(4).getStringCellValue();
                UserName1 = row.getCell(4).getStringCellValue();
                UserName2 = row.getCell(4).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Program__c")){
                ProgramName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Risk_Register__c")){
                RiskRegister = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Change_Request_Log__c")){
                ChangeRequestLogName = row.getCell(3).getStringCellValue();
            }
        }
        //-------------END-------------------------------


        //get sObject URL
       // String sObject = sheet.getRow(18).getCell(2).getStringCellValue();
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 50);

        //click New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Clicking on Associated Organization
        //String OrgName = sheet.getRow(11).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder=\"Search Organization...\"]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on Associated Portfolio
        //String PortName = sheet.getRow(12).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Portfolios...\"]")).sendKeys(PortName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+PortName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on associated program
        //String ProgramName = sheet.getRow(13).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Programs...\"]")).sendKeys(ProgramName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+ProgramName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Issue Log Name
        driver.findElement(By.xpath("//input[@class=\" input\" and @maxlength=\"80\"]")).sendKeys("Test Selenium Issue Log ");
        Thread.sleep(1000);

        //Priority
        driver.findElement(By.xpath("(//a[@class=\"select\"])")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"3-Low\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Risk Register
        //String RiskRegister = sheet.getRow(32).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@title=\"Search Risk Register\"]")).sendKeys(RiskRegister);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+RiskRegister+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Due Date
        driver.findElement(By.xpath("//a[@class=\"datePicker-openIcon display\"]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='17']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Issue Coordinate
        //String UserName = sheet.getRow(37).getCell(4).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"Search People...\"])[1]")));
        myDynamicElement.sendKeys(UserName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+UserName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Issue Impacts
        driver.findElement(By.xpath("(//a[@class=\"select\"])[2]")).click();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"The business\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Issue Owner
        //String UserName1 = sheet.getRow(37).getCell(4).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"Search People...\"])[2]")));
        myDynamicElement.sendKeys(UserName1);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\""+UserName1+"\"])[2]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //clicking on associated ChangeRequestLogName
        //String ChangeRequestLogName = sheet.getRow(21).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Change Request Log...\"]")).sendKeys(ChangeRequestLogName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+ChangeRequestLogName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //issue Signoff Resolution
       // String UserName2 = sheet.getRow(37).getCell(4).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"Search People...\"])[3]")));
        myDynamicElement.sendKeys(UserName2);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\""+UserName2+"\"])[3]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Issue Description
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("testing");
        Thread.sleep(1000);

        //Final Resolution
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("testing");
        Thread.sleep(1000);

        //Recommended Resolution
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("testing");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("testing");
        Thread.sleep(1000);

        //Save IssueLog
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Issue Log \"Test Selenium Issue Log \" was created.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

        //assign url to RecURL variable
        RecURL = driver.getCurrentUrl();
    }

    @Test(priority = 1)
    public void EditIssueLog() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Edit Issue Log
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //click Edit Button
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='Edit'])[2]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Issue Log Name Change
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\" input\" and @maxlength=\"80\"]")));
        myDynamicElement.clear();
        Thread.sleep(1000);
        myDynamicElement.sendKeys("Test Selenium Issue Log-Edit");

        //Priority
        driver.findElement(By.xpath("(//a[@class=\"select\"])")).click();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"2-Medium\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comments
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys(" Test IL");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Issue Log \"Test Selenium Issue Log-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);
    }

    @Test(priority = 2)
    public void AddProject() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String ProjectName ="";



        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("PlatinumPMO__Project__c")){
                ProjectName = row.getCell(3).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        //Add Project
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Add_Project\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //clicking on associated project
        //String ProjectName = sheet.getRow(14).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"search..\"]")).sendKeys(ProjectName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+ProjectName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("//span[text()=\"Add Project\"]")).click();
        Thread.sleep(5000);
    }

    @Test(priority = 3)
    public void AddDeliverable() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String DeliverableName ="";



        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("PlatinumPMO__Deliverable__c")){
                DeliverableName = row.getCell(3).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        //Add Deliverable
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Add_Deliverable\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //clicking on associated DeliverableName
        //String DeliverableName = sheet.getRow(15).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"search..\"]")).sendKeys(DeliverableName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+DeliverableName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("//span[text()='Add Deliverable']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The Object Added";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);
    }

    @Test(priority = 4)
    public void AddCRL() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String SystemName ="";
        String DefectLogName ="";
        String StakeholderGroupsName ="";
        String UserName ="";
        String UserName1 ="";
        String UserName2 ="";

        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("PlatinumPMO__System__c")){
                SystemName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Defect_Log__c")){
                DefectLogName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Stakeholder_Groups__c")){
                StakeholderGroupsName = row.getCell(3).getStringCellValue();
            }

            if(check.equals("User")){
                UserName = row.getCell(3).getStringCellValue();
                UserName1 = row.getCell(3).getStringCellValue();
                UserName2 = row.getCell(3).getStringCellValue();
            }

        }
        //-------------END-------------------------------


        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Create_Change_Request_Log\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //clicking on associated project
        String ProjectName = sheet.getRow(14).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[4]")).sendKeys(ProjectName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+ProjectName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //CRL Name
        driver.findElement(By.xpath("//input[@name=\"Change Request Log Name\"]")).sendKeys("Test Selenium CRL ");
        Thread.sleep(1000);

        //Change Request Description
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Program Phase
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[1]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[@value=\"ASAP: 1- Preparation\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Business Junction
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Change Request Type
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[2]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[@value=\"Business Process\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //clicking on associated DeliverableName
        String DeliverableName = sheet.getRow(15).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[5]")).sendKeys(DeliverableName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+DeliverableName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //clicking on associated SystemName
        //String SystemName = sheet.getRow(33).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[6]")).sendKeys(SystemName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+SystemName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //clicking on associated DefectLogName
        //String DefectLogName = sheet.getRow(25).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[7]")).sendKeys(DefectLogName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+DefectLogName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Change Request Sponsor
       // String UserName = sheet.getRow(37).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"search..\" and @type=\"text\"])[8]")));
        myDynamicElement.sendKeys(UserName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+UserName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Change Review Board
        //String StakeholderGroupsName = sheet.getRow(42).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[9]")).sendKeys(StakeholderGroupsName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+StakeholderGroupsName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Impact Assessment Owner
        //String UserName1 = sheet.getRow(37).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"search..\" and @type=\"text\"])[10]")));
        myDynamicElement.sendKeys(UserName1);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()=\""+UserName1+"\"])[4]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Impact Assessment Due Date
        driver.findElement(By.xpath("(//input[@type=\"text\" and @class=\"slds-input\"])[2]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='15']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Impact Assessment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Estimated Project Hours- Breakdown
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Overall Project Impact
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Potential Workaround
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Estimated Hours to Complete Change
        driver.findElement(By.xpath("(//input[@inputmode=\"decimal\"])[1]")).sendKeys("3");
        Thread.sleep(1000);

        //Estimated Cost for Change
        driver.findElement(By.xpath("(//input[@inputmode=\"decimal\"])[2]")).sendKeys("$50");
        Thread.sleep(1000);

        //System Core Modification
        driver.findElement(By.xpath("//input[@type=\"checkbox\" and @class=\"uiInput uiInputCheckbox uiInput--default uiInput--checkbox\"]")).click();
        Thread.sleep(1000);

        //Change Request Delivery Manager
       // String UserName2 = sheet.getRow(37).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"search..\" and @type=\"text\"])[11]")));
        myDynamicElement.sendKeys(UserName2);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()=\""+UserName2+"\"])[5]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Development Details
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("ok");
        Thread.sleep(1000);

        //Transport Number
        driver.findElement(By.xpath("(//textarea[@class=\"slds-textarea\"])[1]")).sendKeys("32313");
        Thread.sleep(1000);

        //Implementation Notes
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("implemented");
        Thread.sleep(1000);

        //Implementation Environment
        driver.findElement(By.xpath("(//textarea[@class=\"slds-textarea\"])[2]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Save CRL
        driver.findElement(By.xpath("//button[@class=\"slds-button slds-button_brand\"]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Created Test Selenium CRL ";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

    }

    @Test(priority = 5)
    public void SendtoCoordination() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);


        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test STC");
        Thread.sleep(1000);

        //STC Click
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button--neutral slds-button slds-button_brand uiButton\"])[1]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "SUCCESS";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='In Coordination']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }


    @Test(priority = 6)
    public void InResolution() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserAliasName="";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("User_Management")){
                UserAliasName = row.getCell(4).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        //String UserAliasName = sheet.getRow(58).getCell(4).getStringCellValue();
        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test In Resolution");
        Thread.sleep(1000);

        //Click Resolution
        driver.findElement(By.xpath("//span[text()='Send For Resolution']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send For Resolution";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='In Resolution']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }

    @Test(priority = 7)
    public void ReadyToTest() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test RTT");
        Thread.sleep(1000);

        //RTT Click
        driver.findElement(By.xpath("//span[text()='Ready To Test']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully send for Resolved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);


        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Resolved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }

    @Test(priority = 8)
    public void MinorChange() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);


        //Click iCON Button
        WebElement myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Edit Button
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //minor change click
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a minor change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Description
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"ql-editor slds-rich-text-area__content slds-text-color_weak slds-grow\"]")));
        myDynamicElement.clear();
        Thread.sleep(5000);
        myDynamicElement.sendKeys("minor Change");
        Thread.sleep(1000);


        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test minor");
        Thread.sleep(2000);

        //Click Save Button
        driver.findElement(By.xpath("(//span[text()='Save'])")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage=myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue="Issue Log \"Test Selenium Issue Log-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

    }

    @Test(priority = 9)
    public void SignificantChange() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);


        //Click iCON Button
        WebElement myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Edit Button
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Significant change click
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a significant change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Description
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")));
        myDynamicElement.clear();
        Thread.sleep(5000);
        myDynamicElement.sendKeys("significant Change");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test significant");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("(//span[text()='Save'])")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Issue Log \"Test Selenium Issue Log-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);
    }

    @Test(priority = 10)
    public void ReadyToTest1() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test RTT");
        Thread.sleep(1000);

        //RTT Click
        driver.findElement(By.xpath("//span[text()='Ready To Test']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully send for Resolved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);


        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Resolved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }

    @Test(priority = 11)
    public void Approval() throws InterruptedException {

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserAliasName="";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("User_Management")){
                UserAliasName = row.getCell(6).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        //String UserAliasName = sheet.getRow(58).getCell(6).getStringCellValue();
       driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Issue_Log__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Approved");
        Thread.sleep(1000);

        //Approve Click
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button--neutral slds-button slds-button_brand uiButton\"])[1]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Approved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        Thread.sleep(5000);
    }

}
