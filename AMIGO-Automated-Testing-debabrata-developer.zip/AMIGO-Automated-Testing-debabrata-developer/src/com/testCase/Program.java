package com.testCase;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Program extends LOGIN_CLASS {
    String RecURL;

    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    public Program() throws IOException {
    }

    @Test(priority = 1)
    public void CreateProgram() throws InterruptedException {
        //get sObject URL
        String sObject = sheet.getRow(13).getCell(2).getStringCellValue();
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 50);
        //Click On New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Associated Organization
        String OrgName = sheet.getRow(11).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@title=\"Search Organization\"]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"" + OrgName + "\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Associated portfolio
        String PortName = sheet.getRow(12).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@title=\"Search Portfolios\"]")).sendKeys(PortName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"" + PortName + "\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Program Name
        driver.findElement(By.xpath("(//input[@class=\" input\"])[1]")).sendKeys("Test Selenium Program");
        Thread.sleep(1000);

        //Sensitive Data
        driver.findElement(By.xpath("//span[@title=\"HR Sensitive Data\"]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button[@title=\"Move selection to Chosen\"]")).click();
        Thread.sleep(1000);

        //Program Sponsor
        String userName = sheet.getRow(37).getCell(4).getStringCellValue();
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[1]")).sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\"" + userName + "\"])[1]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Business Lead
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[2]")).sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\"" + userName + "\"])[2]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Technology Lead
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[3]")).sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\"" + userName + "\"])[3]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Program manager
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[4]")).sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\"" + userName + "\"])[4]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Financial advisor
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[5]")).sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\"" + userName + "\"])[5]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Administrator
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[6]")).sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@title=\"" + userName + "\"])[6]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Solution Integrator
        String SoluName = sheet.getRow(39).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@title=\"Search Solution Integrator\"]")).sendKeys(SoluName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"" + SoluName + "\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Target Star Date
        driver.findElement(By.xpath("(//a[@class=\"datePicker-openIcon display\"])[1]")).click();
        Thread.sleep(3000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='20']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Target Completion Date
        driver.findElement(By.xpath("(//a[@class=\"datePicker-openIcon display\"])[2]")).click();
        Thread.sleep(3000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@class=\"navLink nextMonth\"]")));
        Thread.sleep(1000);
        myDynamicElement.click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='20']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Estimated Budget
        driver.findElement(By.xpath("//input[@class=\"input uiInputSmartNumber\"]")).sendKeys("500000");
        Thread.sleep(1000);

        //Program Description
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Program Charter
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Program Charter Overflow
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Program \"Test Selenium Program\" was created.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

        //assign url to RecURL variable
        RecURL = driver.getCurrentUrl();

    }

    @Test(priority = 2)
    public void EditProgram() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        //Edit Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@type=\"button\"and @class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Edit
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Edit Popup
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='Edit'])[2]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Name
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@class=\" input\"])[1]")));
        myDynamicElement.clear();
        myDynamicElement.sendKeys("Test Selenium Program-Edit");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment-Edit");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Program \"Test Selenium Program-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

        driver.navigate().refresh();
        Thread.sleep(10000);

    }

    @Test(priority = 3)
    public void AddRaci() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        //Add Raci Chart
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Program__c.PlatinumPMO__RACI_Chart\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //User Type
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@class=\"slds-select\"]")));
        myDynamicElement.click();
        Thread.sleep(3000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Responsible']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //User
        String userName = sheet.getRow(37).getCell(4).getStringCellValue();
        driver.findElement(By.xpath("//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"]")).sendKeys(userName + "\n");
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='" + userName + "']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Change Description
        driver.findElement(By.xpath("//textarea[@name=\"HistoricalComment\"]")).sendKeys("Add RACI");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The record was successfully created.";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        //Add Raci Chart
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Program__c.PlatinumPMO__RACI_Chart\"]")));
        myDynamicElement.click();
        Thread.sleep(2000);

        //User Type
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@class=\"slds-select\"]")));
        myDynamicElement.click();
        Thread.sleep(3000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Accountable']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //User
        driver.findElement(By.xpath("//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"]")).sendKeys(userName + "\n");
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='" + userName + "']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Change Description
        driver.findElement(By.xpath("//textarea[@name=\"HistoricalComment\"]")).sendKeys("Add RACI");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage1 = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval1 = "The record was successfully created.";

        //Check
        Assert.assertTrue(ToastMessage1.contains(Chechval1));
        Thread.sleep(5000);

        //Add Raci Chart
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Program__c.PlatinumPMO__RACI_Chart\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //User Type
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@class=\"slds-select\"]")));
        myDynamicElement.click();
        Thread.sleep(3000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Consulted']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //User
        userName = sheet.getRow(37).getCell(6).getStringCellValue();
        driver.findElement(By.xpath("//input[@class=\"slds-lookup__search-input slds-input inputSize input uiInput uiInputText uiInput--default uiInput--input\"]")).sendKeys(userName + "\n");
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='" + userName + "']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Chasnge Description
        driver.findElement(By.xpath("//textarea[@name=\"HistoricalComment\"]")).sendKeys("Add RACI");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage2 = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval2 = "The record was successfully created.";

        //Check
        Assert.assertTrue(ToastMessage2.contains(Chechval2));
        Thread.sleep(5000);
    }

    @Test(priority = 4)
    public void AddUser() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Add User Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Add_User\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Search User
        String userName = sheet.getRow(37).getCell(8).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\"slds-lookup__search-input slds-input inputSize input uiInput uiInputText uiInput--default uiInput--input\"]")));
        myDynamicElement.sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='" + userName + "']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //get toast message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The Record was Saved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);
    }

    @Test(priority = 5)
    public void AddProject() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Add Project
        WebElement element = driver.findElement(By.xpath("//button[@name=\"PlatinumPMO__Program__c.PlatinumPMO__AddNewProject\"]"));
        Actions actions = new Actions(driver);
        actions.moveToElement(element).click().build().perform();
        Thread.sleep(5000);

        //Project Name
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name=\"Project Name\"]")));
        Thread.sleep(2000);
        myDynamicElement.sendKeys("Test Selenium Project");
        Thread.sleep(1000);

        //Project Description
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Target Start Date
        WebElement element1 = driver.findElement(By.xpath("//input[@name=\"TargetStartDate\"]"));
        Actions actions1 = new Actions(driver);
        actions1.moveToElement(element1).click().build().perform();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//span[text()='17']")).click();
        Thread.sleep(1000);

        //Target Completion Date
        WebElement element2 = driver.findElement(By.xpath("//input[@name=\"TargetCompletionDate\"]"));
        Actions actions2 = new Actions(driver);
        actions2.moveToElement(element2).click().build().perform();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//span[text()='30']")).click();
        Thread.sleep(1000);

        //Estimated Budget
        driver.findElement(By.xpath("//input[@name=\"EstimatedBudget\"]")).sendKeys("2000");
        Thread.sleep(1000);

        //Capital
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[3]")).click();
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Capital']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Business Process Manager
        String userName = sheet.getRow(37).getCell(4).getStringCellValue();
        driver.findElement(By.xpath("(//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"])[4]")).sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='" + userName + "'])[1]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Timesheet Approver
        driver.findElement(By.xpath("(//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"])[6]")).sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='" + userName + "'])[4]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //project Condition
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[1]")).click();
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Red']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Project Phase
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[2]")).click();
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='ASAP: 0- Initiation']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Associated Solution Integrator
        String SoluName = sheet.getRow(39).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"])[5]")).sendKeys(SoluName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='" + SoluName + "']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Expense Approver
        driver.findElement(By.xpath("(//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"])[7]")).sendKeys(userName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='" + userName + "'])[7]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //get toast message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--info slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The record was saved.";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);
    }

    @Test(priority = 6)
    public void AddTemplate() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //Click Icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click ADD Template Button
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Add Template']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Program Template
        String ProgramTemp = sheet.getRow(45).getCell(5).getStringCellValue();
        driver.findElement(By.xpath("//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"]")).sendKeys(ProgramTemp);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\"" + ProgramTemp + "\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comments
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("test Template ");
        Thread.sleep(1000);

        //ADD Template
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button--neutral uiButton\"])[1]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The Records Saved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);
    }

    @Test(priority = 7)
    public void SubmitforApproval1() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Submit For Approval");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//span[text()='Send For Approval']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send For Apporval";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

       myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='In Approval']")));
       Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }
    @Test(priority = 8)
    public void MinorEditforautoreject () throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Edit Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@type=\"button\"and @class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Edit
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click On Minor Edit
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a minor change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Program Phase
        driver.findElement(By.xpath("(//a[@class=\"select\"])[1]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[@title=\"ASAP: 1- Preparation\"]")).click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment-Edit");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Program \"Test Selenium Program-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='In Approval']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

        driver.get(RecURL);
        Thread.sleep(10000);
    }
    @Test(priority = 9)
    public void MajorEditforautoreject() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Edit Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@type=\"button\"and @class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Edit
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Click on Significant Edit
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a significant change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //program Condition
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@class=\"select\"])[2]")));
        myDynamicElement.click();
        Thread.sleep(1000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@title=\"Yellow\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//span[text()='Save']")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Program \"Test Selenium Program-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Rejected: In Process']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

        driver.get(RecURL);
        Thread.sleep(5000);
    }

    @Test(priority = 10)
    public void SubmitForApproval2() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Submit For Approval");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//span[text()='Send For Approval']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send For Apporval";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='In Approval']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }

    @Test(priority = 11)
    public void Rejected() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserAliasName = sheet.getRow(58).getCell(4).getStringCellValue();
        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Reject");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//span[text()='Reject']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Reject";

        //Check
        Thread.sleep(5000);

       myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Rejected: In Process']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);
    }

    @Test(priority = 12)
    public void SubmitforApproval3() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Submit For Appropval");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//span[text()='Send For Approval']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send For Apporval";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        Assert.assertTrue(driver.findElement(By.xpath("//lightning-formatted-text[text()='In Approval']"))!= null);
        Thread.sleep(5000);

    }

    @Test(priority = 13)
    public void Approve1() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click icon
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //click Take Action
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Approve");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//span[text()='Approve']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

    }

    @Test(priority = 14)
    public void Approve2() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserAliasName = sheet.getRow(58).getCell(6).getStringCellValue();
        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //Click dropdown
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Click On Take Action
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Program__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Approve");
        Thread.sleep(1000);

        //Click on Approve
        driver.findElement(By.xpath("//span[text()='Approve']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

      myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Approved']")));
       Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

        driver = AnyUserLogin.LoginAnyUser(driver,"login");

        Thread.sleep(10000);

        driver.get(RecURL);
        Thread.sleep(5000);

    }
}
