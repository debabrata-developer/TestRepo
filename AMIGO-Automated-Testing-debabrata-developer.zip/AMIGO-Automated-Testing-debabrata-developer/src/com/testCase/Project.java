package com.testCase;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Project extends LOGIN_CLASS{
    String RecURL;

    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    public Project() throws IOException {
    }

    @Test(priority = 1)
    public void CreateNewProject () throws InterruptedException {
        //get sObject URL
        String sObject = sheet.getRow(14).getCell(2).getStringCellValue();
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 50);

        //Clicking on New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a/div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Clicking on Associated Organization
        String OrgName = sheet.getRow(11).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder=\"Search Organization...\"]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on Associated Portfolio
        String portName = sheet.getRow(12).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Portfolios...\"]")).sendKeys(portName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+portName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on associated program
        String ProgName = sheet.getRow(13).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Programs...\"]")).sendKeys(ProgName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+ProgName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Name of Project
        driver.findElement(By.xpath("(//input[@class=\" input\"])[1]")).sendKeys("Test Selenium Project");
        Thread.sleep(1000);

        //project description
        driver.findElement(By.xpath("//textarea[@class=\" textarea\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //target start date
        driver.findElement(By.xpath("(//a[@class=\"datePicker-openIcon display\"])[1]")).click();
        Thread.sleep(1000);
        //select date
        driver.findElement(By.xpath("//span[text()='14']")).click();
        Thread.sleep(1000);

        //target completion date
        driver.findElement(By.xpath("(//a[@class=\"datePicker-openIcon display\"])[2]")).click();
        Thread.sleep(1000);

        //arrow of datepicker
        driver.findElement(By.xpath("//a[@title=\"Go to next month\"]")).click();
        Thread.sleep(1000);
        //select date
        driver.findElement(By.xpath("//span[text()='20']")).click();
        Thread.sleep(1000);

        //Budget
        driver.findElement(By.xpath("//input[@class=\"input uiInputSmartNumber\"]")).sendKeys("5000000");
        Thread.sleep(1000);

        //capital
        driver.findElement(By.xpath("(//a[@class=\"select\"])[3]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[@title=\"Capital\"]")).click();
        Thread.sleep(1000);

        //timesheet approver
        String userName = sheet.getRow(37).getCell(4).getStringCellValue();
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[3]")).sendKeys(userName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+userName+"\"]")).click();
        Thread.sleep(1000);

        //project condition
        driver.findElement(By.xpath("(//a[@class=\"select\"])[1]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[@title=\"Yellow\"]")).click();
        Thread.sleep(1000);

        //Project Phase
        driver.findElement(By.xpath("(//a[@class=\"select\"])[2]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[@title=\"ASAP: 0- Initiation\"]")).click();
        Thread.sleep(1000);

        //project manager
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[1]")).sendKeys(userName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+userName+"\"]")).click();
        Thread.sleep(1000);

        //Business Process Manager
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[2]")).sendKeys(userName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("(//div[@title=\""+userName+"\"])[2]")).click();
        Thread.sleep(1000);

        //Solution Integrator
        String SoluName = sheet.getRow(39).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@title=\"Search Solution Integrator\"]")).sendKeys(SoluName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+SoluName+"\"]")).click();
        Thread.sleep(1000);

        //Expense Approver
        driver.findElement(By.xpath("(//input[@title=\"Search People\"])[4]")).sendKeys(userName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("(//div[@title=\""+userName+"\"])[4]")).click();
        Thread.sleep(1000);

        //Project Charter
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Project Charter Overflow
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Project \"Test Selenium Project\" was created.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

        RecURL=driver.getCurrentUrl();

    }

    @Test(priority = 2)
    public void EditProject () throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Edit Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Edit
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Project__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Edit Popup
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='Edit'])[2]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Name of Project
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@class=\" input\"])[1]")));
        myDynamicElement.clear();
        myDynamicElement.sendKeys("Test Selenium Project-Edit");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment-Edit");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "Project \"Test Selenium Project-Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

        driver.navigate().refresh();
        Thread.sleep(10000);

    }
    @Test(priority = 3)
    public void AddRaci() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        //Add Raci Chart
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Project__c.PlatinumPMO__RACI_Chart\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //User Type
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@class=\"slds-select\"]")));
        myDynamicElement.click();
        Thread.sleep(3000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Responsible']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //User
        String userName = sheet.getRow(37).getCell(4).getStringCellValue();
        driver.findElement(By.xpath("//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"]")).sendKeys(userName+"\n");
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='"+userName+"']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Change Description
        driver.findElement(By.xpath("//textarea[@name=\"HistoricalComment\"]")).sendKeys("Add RACI");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The record was successfully created.";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        //Add Raci Chart
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Project__c.PlatinumPMO__RACI_Chart\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //User Type
        myDynamicElement= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@class=\"slds-select\"]")));
        myDynamicElement.click();
        Thread.sleep(3000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Accountable']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //User
        driver.findElement(By.xpath("//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"]")).sendKeys(userName+"\n");
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='"+userName+"']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Change Description
        driver.findElement(By.xpath("//textarea[@name=\"HistoricalComment\"]")).sendKeys("Add RACI");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage1 = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval1 = "The record was successfully created.";

        //Check
        Assert.assertTrue(ToastMessage1.contains(Chechval1));
        Thread.sleep(5000);

        //Add Raci Chart
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Project__c.PlatinumPMO__RACI_Chart\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //User Type
        myDynamicElement= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@class=\"slds-select\"]")));
        myDynamicElement.click();
        Thread.sleep(3000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Consulted']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //User
        userName = sheet.getRow(37).getCell(6).getStringCellValue();
        driver.findElement(By.xpath("//input[@class=\"slds-lookup__search-input slds-input inputSize input uiInput uiInputText uiInput--default uiInput--input\"]")).sendKeys(userName+"\n");
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='"+userName+"']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Chasnge Description
        driver.findElement(By.xpath("//textarea[@name=\"HistoricalComment\"]")).sendKeys("Add RACI");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage2 = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval2 = "The record was successfully created.";


        //Check
        Assert.assertTrue(ToastMessage2.contains(Chechval2));
        Thread.sleep(5000);
    }
    @Test(priority = 4)
    public void AddDeliverable() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        //Add Deliverable
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Add Deliverable']")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Deliverable Name
        driver.findElement(By.xpath("//input[@name=\"Deliverable Name\"]")).sendKeys("Test Selenium Delivrable");
        Thread.sleep(1000);

        //Deleverable Description
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Testing");
        Thread.sleep(1000);

        //Sensitive Data
        WebElement element = driver.findElement(By.xpath("//span[text()='HR Sensitive Data']"));
        Actions actions = new Actions(driver);
        actions.moveToElement(element).click().build().perform();
        Thread.sleep(2000);
        WebElement element1 = driver.findElement(By.xpath("//button[@title=\"Move selection to Chosen\"]"));
        Actions actions1 = new Actions(driver);
        actions1.moveToElement(element1).click().build().perform();
        Thread.sleep(1000);

        //Deliverable Type
        String DelivName = sheet.getRow(44).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"])[5]")).sendKeys(DelivName);
        Thread.sleep(3000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='"+DelivName+"']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Associated Business Process
        String BPName = sheet.getRow(19).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"])[6]")).sendKeys(BPName);
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='"+BPName+"']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Measure And Metrics
        String MandMName = sheet.getRow(43).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"])[7]")).sendKeys(MandMName);
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='"+MandMName+"']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //StakeHolder Group
        String StakeName = sheet.getRow(42).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"])[8]")).sendKeys(StakeName);
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='"+StakeName+"']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Associated Object
        String ObjName = sheet.getRow(31).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("(//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"])[9]")).sendKeys(ObjName);
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='"+ObjName+"']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Scope Description
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[1]")).click();
        Thread.sleep(3000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='In Scope']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Capital
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[2]")).click();
        Thread.sleep(3000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Capital']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Scope Lever
        driver.findElement(By.xpath("(//select[@class=\"slds-select\"])[3]")).click();
        Thread.sleep(3000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Business Process']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //get toast message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--info slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The record was saved.";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);
    }

    @Test(priority = 5)
    public void AddTemplate() throws InterruptedException {
        driver.get(RecURL);

        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

        Thread.sleep(5000);

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Add Template
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Project__c.PlatinumPMO__Add_Template\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Project Template
        String ProjectTemp = sheet.getRow(45).getCell(4).getStringCellValue();
        driver.findElement(By.xpath("//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"]")).sendKeys(ProjectTemp);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+ProjectTemp+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Add
        driver.findElement(By.xpath("//button[text()='Add']")).click();
        Thread.sleep(1000);

        //get toast message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The Records Saved";


        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

    }
    @Test(priority = 6)
    public void SubmitForApproval1() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click dropdown
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Click On Take Action
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Take Action']")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")));
        myDynamicElement.sendKeys("Submit For Approval");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[text()='Send For Approval']")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue ="Successfully Send For Apporval";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

        Assert.assertTrue(driver.findElement(By.xpath("//lightning-formatted-text[text()='In Approval']"))!= null);
        Thread.sleep(5000);
    }
  @Test(priority = 7)
    public void MinorEditforautoreject () throws InterruptedException {
      WebDriverWait wait = new WebDriverWait(driver, 30);

      //Edit Button
      WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
      myDynamicElement.click();
      Thread.sleep(1000);

      //Edit
      myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Project__c.PlatinumPMO__Edit\"]")));
      myDynamicElement.click();
      Thread.sleep(1000);

      //click On Minor Edit
      myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a minor change']")));
      myDynamicElement.click();
      Thread.sleep(5000);

      //project condition
      driver.findElement(By.xpath("(//a[@class=\"select\"])[1]")).click();
      Thread.sleep(1000);
      driver.findElement(By.xpath("//a[@title=\"Can not determine\"]")).click();
      Thread.sleep(1000);

      //Project Phase
      driver.findElement(By.xpath("(//a[@class=\"select\"])[2]")).click();
      Thread.sleep(1000);
      driver.findElement(By.xpath("//a[@title=\"ASAP: 1- Preparation\"]")).click();
      Thread.sleep(1000);

      //Historical Comment
      driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
      Thread.sleep(1000);

      //Save
      driver.findElement(By.xpath("//span[text()='Save']")).click();
      Thread.sleep(1000);

      //get Toast Message
      myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
      String ToastMessage = myDynamicElement.getAttribute("innerHTML");

      //Expected Toast Message Value Set
      String ExpectedValue = "Project \"Test Selenium Project-Edit\" was saved.";

      //Check
      Assert.assertEquals(ToastMessage,ExpectedValue);

      Thread.sleep(5000);

     driver.get(RecURL);
     Thread.sleep(5000);
    }

     @Test(priority = 8)
    public void MajorEditforautoreject() throws InterruptedException {
         WebDriverWait wait = new WebDriverWait(driver, 30);

         //Edit Button
         WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
         myDynamicElement.click();
         Thread.sleep(1000);

        //Edit
         myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__Project__c.PlatinumPMO__Edit\"]")));
         myDynamicElement.click();
         Thread.sleep(5000);

         //Click on Significat Edit
         myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a significant change']")));
         myDynamicElement.click();
         Thread.sleep(1000);

         //project description
         driver.findElement(By.xpath("//textarea[@class=\" textarea\"]")).sendKeys("Testing Project");
         Thread.sleep(1000);

         //Historical Comment
         driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Historical Comment");
         Thread.sleep(1000);

         //Save
         driver.findElement(By.xpath("//span[text()='Save']")).click();
         Thread.sleep(1000);

         //get Toast Message
         myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
         String ToastMessage = myDynamicElement.getAttribute("innerHTML");

         //Expected Toast Message Value Set
         String ExpectedValue = "Project \"Test Selenium Project-Edit\" was saved.";

         //Check
         Assert.assertEquals(ToastMessage,ExpectedValue);

         Thread.sleep(5000);

         driver.get(RecURL);
         Thread.sleep(5000);

     }

    @Test(priority = 9)
    public void SubmitForApproval2() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click dropdown
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Click On Take Action
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Take Action']")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")));
        myDynamicElement.sendKeys("Submit For Approval");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[text()='Send For Approval']")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue ="Successfully Send For Apporval";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

        Assert.assertTrue(driver.findElement(By.xpath("//lightning-formatted-text[text()='In Approval']"))!= null);
        Thread.sleep(5000);
    }

    @Test(priority = 10)
    public void Reject() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserAliasName = sheet.getRow(58).getCell(4).getStringCellValue();
        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //Click dropdown
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Click On Take Action
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Take Action']")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Reject");
        Thread.sleep(1000);

        //Click on Reject
        driver.findElement(By.xpath("//span[text()='Reject']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Reject";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        Assert.assertTrue(driver.findElement(By.xpath("//lightning-formatted-text[text()='Rejected: In Process']"))!= null);
        Thread.sleep(5000);
    }
    @Test(priority = 11)
    public void SubmitForApproval3() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click dropdown
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Click On Take Action
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Take Action']")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")));
        myDynamicElement.sendKeys("Submit For Approval");
        Thread.sleep(1000);

        //Click On Submit For Approval
        driver.findElement(By.xpath("//span[text()='Send For Approval']")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue ="Successfully Send For Apporval";

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

        Assert.assertTrue(driver.findElement(By.xpath("//lightning-formatted-text[text()='In Approval']"))!= null);
        Thread.sleep(5000);
    }
    @Test(priority = 12)
    public void Approve1() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click dropdown
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Click On Take Action
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Take Action']")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Approve");
        Thread.sleep(1000);

        //Click on Approve
        driver.findElement(By.xpath("//span[text()='Approve']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

    }
    @Test(priority = 13)
    public void Approve2() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

        String UserAliasName = sheet.getRow(58).getCell(6).getStringCellValue();
        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //Click dropdown
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Click On Take Action
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Take Action']")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Approve");
        Thread.sleep(1000);

        //Click on Approve
        driver.findElement(By.xpath("//span[text()='Approve']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        Assert.assertTrue(driver.findElement(By.xpath("//lightning-formatted-text[text()='Approved']"))!= null);
        Thread.sleep(5000);

        driver = AnyUserLogin.LoginAnyUser(driver,"login");

        Thread.sleep(10000);

        driver.get(RecURL);
        Thread.sleep(5000);

    }



}
