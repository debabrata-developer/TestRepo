package com.testCase;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class System_obj extends LOGIN_CLASS {
    String RecURL;

    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();


    public System_obj() throws IOException, IOException {
    }

    @Test(priority = 0)
    public void CreateSystem() throws InterruptedException {

        String sObject = "";
        String OrgName = "";
        String PortName = "";
        String ProgramName  = "";



        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();
            if(check.equals("PlatinumPMO__System__c")){
                sObject = row.getCell(2).getStringCellValue();
                //System.out.println("the if value--->"+row.getCell(2).getStringCellValue());
            }
            if(check.equals("PlatinumPMO__Organization__c")){
                OrgName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Portfolio__c")){
                PortName = row.getCell(3).getStringCellValue();
            }

            if(check.equals("PlatinumPMO__Program__c")){
                ProgramName = row.getCell(3).getStringCellValue();
            }
        }
        //-------------END-------------------------------

        //get sObject URL
      //  String sObject = sheet.getRow(33).getCell(2).getStringCellValue();
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 50);

        //click New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Clicking on Associated Organization
        //String OrgName = sheet.getRow(11).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder=\"Search Organization...\"]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on Associated Portfolio
        //String PortName = sheet.getRow(12).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Portfolios...\"]")).sendKeys(PortName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[@title=\""+PortName+"\"]")).click();
        Thread.sleep(1000);

        //clicking on associated program
        //String ProgramName = sheet.getRow(13).getCell(3).getStringCellValue();
        driver.findElement(By.xpath("//input[@placeholder=\"Search Programs...\"]")).sendKeys(ProgramName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+ProgramName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //System Name
        driver.findElement(By.xpath("//input[@class=\" input\" and @maxlength=\"80\"]")).sendKeys("Test Selenium System Create");
        Thread.sleep(1000);

        //System Type
        driver.findElement(By.xpath("(//a[@class=\"select\" and @role=\"button\"])[1]")).sendKeys("Future System");
        Thread.sleep(1000);

        //System Disposition
        driver.findElement(By.xpath("(//a[@class=\"select\"])[2]")).sendKeys("Continue after go live");
        Thread.sleep(1000);

        //Description
        driver.findElement(By.xpath("(//textarea[@class=\" textarea\"])[1]")).sendKeys("New System Selenium test");
        Thread.sleep(1000);

        //Decommission?
        driver.findElement(By.xpath("//input[@type=\"checkbox\"]")).click();
        Thread.sleep(1000);

        //Date
        driver.findElement(By.xpath("//a[@class=\"datePicker-openIcon display\"]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='15']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Time
        driver.findElement(By.xpath("//a[@class=\"timePicker-openIcon display\"]")).click();
        Thread.sleep(1000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@data-hours=\"00\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("(//textarea[@class=\" textarea\"])[2]")).sendKeys("test");
        Thread.sleep(1000);

        //Save System
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");
        System.out.println("the toast message value--->" + ToastMessage);

        //Expected Toast Message Value Set
        String ExpectedValue = "System \"Test Selenium System Create\" was created.";
        System.out.println("the ExpectedValue--->" + ExpectedValue);

        //Check
        Assert.assertEquals(ToastMessage, ExpectedValue);

        Thread.sleep(5000);

        //assign url to RecURL variable
        RecURL = driver.getCurrentUrl();
    }

    @Test(priority = 2)
    public void EditSystem() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Edit System
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //click Edit Button
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@name=\"PlatinumPMO__System__c.PlatinumPMO__EDIT\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='Edit'])")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //System Name Change
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\" input\" and @maxlength=\"80\"]")));
        myDynamicElement.clear();
        myDynamicElement.sendKeys(" TEST Selenium New System Edit");
        Thread.sleep(1000);

        //System Type
        driver.findElement(By.xpath("(//a[@class=\"select\" and @role=\"button\"])[1]")).sendKeys("Legacy System");
        Thread.sleep(1000);

        //Historical Comments
        driver.findElement(By.xpath("(//textarea[@class=\" textarea\"])[2]")).sendKeys(" Test New System");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("//button[@title=\"Save\"]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"toastMessage slds-text-heading--small forceActionsText\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue = "System \" TEST Selenium New System Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);
    }

    @Test(priority = 3)
    public void AddDataTable() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserName = "";



        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("User")){
                UserName = row.getCell(3).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        //Add Data Table
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__System__c.PlatinumPMO__Add_Data_Table\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Data Table Name
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\" input\" and @maxlength=\"80\"]")));
        myDynamicElement.sendKeys("TEST NEW DATA TABLE");
        Thread.sleep(1000);

        //Data Consistency Factor
        driver.findElement(By.xpath("(//a[@class=\"select\"])[1]")).sendKeys("2");
        Thread.sleep(1000);

        //Data Table Description
        driver.findElement(By.xpath("(//textarea[@class=\" textarea\"])[1]")).sendKeys("Data Table Create");
        Thread.sleep(1000);

        //Data Reliability Factor
        driver.findElement(By.xpath("(//a[@class=\"select\"])[2]")).sendKeys("B");
        Thread.sleep(1000);

        //Business Domain Expert
        //String UserName = sheet.getRow(37).getCell(3).getStringCellValue();
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@title=\"Search People\"]")));
        myDynamicElement.sendKeys(UserName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\""+UserName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comments
        driver.findElement(By.xpath("(//textarea[@class=\" textarea\"])[2]")).sendKeys(" Test New ");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("(//span[text()='Save'])[3]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "was created.";


        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

    }

    @Test(priority = 4)
    public void AddRaci() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserName = "";
        String UserName1 = "";
        String UserName2 = "";

        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("User")){
                UserName = row.getCell(4).getStringCellValue();
                UserName1 = row.getCell(4).getStringCellValue();
                UserName2 = row.getCell(6).getStringCellValue();


            }

        }
        //-------------END-------------------------------

        //Add Raci Chart
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__System__c.PlatinumPMO__RACI_Chart\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //User Type
        myDynamicElement= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@class=\"slds-select\"]")));
        myDynamicElement.click();
        Thread.sleep(3000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Responsible']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //User
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"]")));
        myDynamicElement.sendKeys(UserName);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+UserName+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//textarea[@name=\"HistoricalComment\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The record was successfully created.";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        //Add Raci Chart
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__System__c.PlatinumPMO__RACI_Chart\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //User Type
        myDynamicElement= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@class=\"slds-select\"]")));
        myDynamicElement.click();
        Thread.sleep(3000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Accountable']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //User
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\"slds-lookup__search-input slds-input leftPaddingClass input uiInput uiInputText uiInput--default uiInput--input\"]")));
        myDynamicElement.sendKeys(UserName1);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+UserName1+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//textarea[@name=\"HistoricalComment\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage1 = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval1 = "The record was successfully created.";

        //Check
        Assert.assertTrue(ToastMessage1.contains(Chechval1));
        Thread.sleep(5000);

        //Add Raci Chart
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__System__c.PlatinumPMO__RACI_Chart\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //User Type
        myDynamicElement= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@class=\"slds-select\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//option[text()='Consulted']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //User
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class=\"slds-lookup__search-input slds-input inputSize input uiInput uiInputText uiInput--default uiInput--input\"]")));
        myDynamicElement.sendKeys(UserName2);
        Thread.sleep(5000);
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=\""+UserName2+"\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//textarea[@name=\"HistoricalComment\"]")).sendKeys("Test Historical Comment");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage2 = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval2 = "The record was successfully created.";

        //Check
        Assert.assertTrue(ToastMessage2.contains(Chechval2));
        Thread.sleep(7000);
    }


    @Test(priority = 5)
    public void SubmitforApproval1() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__System__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test SFA");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//span[text()='Send For Approval']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send For Apporval";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='System In Approval']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

    }

    @Test(priority = 6)
    public void MinorChange() throws InterruptedException {

        String UserAliasName="";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("User_Management")){
                UserAliasName = row.getCell(4).getStringCellValue();

            }

        }
        //-------------END-------------------------------



        WebDriverWait wait = new WebDriverWait(driver, 30);


       driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //Edit System
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);


        //Click Edit Button
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='EDIT']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //minor change click
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a minor change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Description
        driver.findElement(By.xpath("(//textarea[@class=\" textarea\"])[1]")).sendKeys("minor Change");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("(//textarea[@class=\" textarea\"])[2]")).sendKeys("Test minor");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("(//span[text()='Save'])")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage=myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue="System \" TEST Selenium New System Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

    }
    @Test(priority = 7)
    public void SignificantChange() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Edit System
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@class=\"slds-button slds-button_icon-border-filled\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);


        //Click Edit Button
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='EDIT']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Significant change click
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a significant change']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Description
        driver.findElement(By.xpath("(//textarea[@class=\" textarea\"])[1]")).sendKeys("significant Change");
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("(//textarea[@class=\" textarea\"])[2]")).sendKeys("Test Significant");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("(//span[text()='Save'])")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage=myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue="System \" TEST Selenium New System Edit\" was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

    }
    

    @Test(priority = 7)
    public void SubmitforApproval2() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__System__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test SFA");
        Thread.sleep(1000);

        //SFA
        driver.findElement(By.xpath("//span[text()='Send For Approval']")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send For Apporval";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='System In Approval']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

    }

    @Test(priority = 8)
    public void Approval1st() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__System__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Approved");
        Thread.sleep(1000);

        //Approve Click
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button--neutral slds-button slds-button_brand uiButton\"])[1]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);
    }


    @Test(priority = 9)
    public void Approval2nd() throws InterruptedException {

        String UserAliasName="";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("User_Management")){
                UserAliasName = row.getCell(6).getStringCellValue();

            }

        }
        //-------------END-------------------------------

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 30);


        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__System__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Approved");
        Thread.sleep(1000);

        //Approve Click
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button--neutral slds-button slds-button_brand uiButton\"])[1]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Approved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        Thread.sleep(5000);
    }
}
