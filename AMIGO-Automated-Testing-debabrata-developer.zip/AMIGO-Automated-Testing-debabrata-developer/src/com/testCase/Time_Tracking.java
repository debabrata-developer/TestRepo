package com.testCase;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Time_Tracking extends LOGIN_CLASS{
    String RecURL;

    // Read Excel File
    File src = new File("C:\\AMIGO Selenium Excel Sheet.xlsx");
    FileInputStream input = new FileInputStream(src);
    XSSFWorkbook workbook = new XSSFWorkbook(input);
    XSSFSheet sheet = workbook.getSheetAt(0);

    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();


    public Time_Tracking() throws IOException, IOException {
    }

    @Test(priority = 0)
    public void CreateTimeTracking() throws InterruptedException {

        String sObject = "";
        String OrgName = "";
        String PortName = "";
        String ProgName = "";
        String ProjectName ="";
        String WPName ="";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();
            if(check.equals("PlatinumPMO__Time_Tracking__c")){
                sObject = row.getCell(2).getStringCellValue();
                //System.out.println("the if value--->"+row.getCell(2).getStringCellValue());
            }
            if(check.equals("PlatinumPMO__Organization__c")){
                OrgName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Portfolio__c")){
                PortName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Program__c")){
                ProgName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("PlatinumPMO__Project__c")){
                ProjectName = row.getCell(3).getStringCellValue();
            }
            if(check.equals("(//span[text()='Save'])")){
                WPName = row.getCell(3).getStringCellValue();
            }
        }
        //-------------END-------------------------------




        //get sObject URL
        System.out.println(sObject);

        //redirect to sObject
        driver.get(sObject);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        WebDriverWait wait = new WebDriverWait(driver, 30);

        //click New Button
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title=\"New\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Time Report
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"search..\"])[1]")));
        myDynamicElement.sendKeys("TR");
        Thread.sleep(5000);
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"slds-listbox__option-text slds-listbox__option-text_entity\"]")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //For Organization lookup
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@placeholder=\"search..\"])[2]")));
        myDynamicElement.sendKeys(OrgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+OrgName+"\"]")).click();
        Thread.sleep(1000);

        //Associated Portfolio
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[3]")).sendKeys(PortName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+PortName+"\"]")).click();
        Thread.sleep(1000);

        //Associated Program
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[4]")).sendKeys(ProgName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+ProgName+"\"]")).click();
        Thread.sleep(1000);

        //Associated Project
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[5]")).sendKeys(ProjectName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+ProjectName+"\"]")).click();
        Thread.sleep(1000);

        //Associated WorkPackage
        driver.findElement(By.xpath("(//input[@placeholder=\"search..\"])[6]")).sendKeys(WPName);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[text()=\""+WPName+"\"]")).click();
        Thread.sleep(1000);

        //Bilable
        driver.findElement(By.xpath("//span[@class=\"slds-checkbox_faux\"]")).click();
        Thread.sleep(1000);

        //Hours
        driver.findElement(By.xpath("//input[@name=\"TimeHours\"]")).sendKeys("4 hours");
        Thread.sleep(1000);

        //Comments
        driver.findElement(By.xpath("//textarea[@class=\"slds-size--1-of-1 slds-p-horizontal_x-small textarea\"]")).sendKeys("test");
        Thread.sleep(1000);

        //Save TimeTracking
        driver.findElement(By.xpath("//button[@class=\"slds-button slds-button_brand\"]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "The record was Successfully Inserted.";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        //assign url to RecURL variable
        RecURL = driver.getCurrentUrl();

    }
    @Test(priority = 1)
    public void TimeReportSubmitForApproval() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click On Time Report
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'TR-0')]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //SFA CLICK
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Submit For Approval']")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test SFA");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[@class=\"slds-button slds-button_success\"]")).click();
        Thread.sleep(5000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send For Approve";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Time Report in Approval']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

    }

    @Test(priority = 2)
    public void minorchange() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        String UserAliasName="";


        //-----dynamically fetch value from excel------
        for(int i=0; i<rowCount+1; i++){
            Row row = sheet.getRow(i);
            String check = row.getCell(1).getStringCellValue();


            if(check.equals("User_Management")){
                UserAliasName = row.getCell(4).getStringCellValue();

            }

        }
        //-------------END-------------------------------



        driver = AnyUserLogin.LoginAnyUser(driver,UserAliasName);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //Edit Time Tracking
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Time_Tracking__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);


        //minor change click
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a minor change']")));
        myDynamicElement.click();
        Thread.sleep(1000);


        //Historical Comment
        driver.findElement(By.xpath("(//textarea[@class=\"slds-size--1-of-1 slds-p-horizontal_x-small textarea\" and @role=\"textbox\"])[2]")).sendKeys("Test minor");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button_brand\"])[2]")).click();
        Thread.sleep(1000);

        //get Toast Message
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage=myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue="The record was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

    }
    @Test(priority = 3)
    public void SignificantChange() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Edit Time Tracking
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Time_Tracking__c.PlatinumPMO__Edit\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);


        //Significant change click
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='This is a significant change']")));
        myDynamicElement.click();
        Thread.sleep(1000);


        //Historical Comment
        driver.findElement(By.xpath("(//textarea[@class=\"slds-size--1-of-1 slds-p-horizontal_x-small textarea\" and @role=\"textbox\"])[2]")).sendKeys("Test sig");
        Thread.sleep(1000);

        //Click Save Button
        driver.findElement(By.xpath("(//button[@class=\"slds-button slds-button_brand\"])[2]")).click();
        Thread.sleep(1000);


        //get Toast Message
        myDynamicElement=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage=myDynamicElement.getAttribute("innerHTML");

        //Expected Toast Message Value Set
        String ExpectedValue="The record was saved.";

        //Check
        Assert.assertEquals(ToastMessage,ExpectedValue);

        Thread.sleep(5000);

    }






    @Test(priority = 4)
    public void SubmitforApproval1() throws InterruptedException {
        Thread.sleep(5000);
        WebDriverWait wait = new WebDriverWait(driver, 30);

        //Click On Time Report
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'TR-0')]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //SFA CLICK
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Submit For Approval']")));
        myDynamicElement.click();
        Thread.sleep(1000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test SFA");
        Thread.sleep(1000);

        //Save
        driver.findElement(By.xpath("//button[@class=\"slds-button slds-button_success\"]")).click();
        Thread.sleep(5000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Send For Approve";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Time Report in Approval']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

    }

    @Test(priority = 5)
    public void Approval() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        driver.get(RecURL);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //click Take Action
        WebElement myDynamicElement = (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@name=\"PlatinumPMO__Time_Tracking__c.PlatinumPMO__Take_Action\"]")));
        myDynamicElement.click();
        Thread.sleep(5000);

        //Historical Comment
        driver.findElement(By.xpath("//div[@class=\"ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow\"]")).sendKeys("Test Approve");
        Thread.sleep(1000);

        //Approval Click
        driver.findElement(By.xpath("//button[@title=\"Approve action\"]")).click();
        Thread.sleep(1000);

        //Get Toast Message
        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"slds-theme--success slds-notify--toast slds-notify slds-notify--toast forceToastMessage\"]")));
        String ToastMessage = myDynamicElement.getAttribute("innerHTML");

        //checking Toast Message Value Set
        String Chechval = "Successfully Approved";

        //Check
        Assert.assertTrue(ToastMessage.contains(Chechval));
        Thread.sleep(5000);

        myDynamicElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//lightning-formatted-text[text()='Approved']")));
        Assert.assertTrue(myDynamicElement!= null);
        Thread.sleep(5000);

        driver = AnyUserLogin.LoginAnyUser(driver,"login");
        Thread.sleep(5000);

    }

}
